#My package
This library was created as an example of how to publish your own Python package.

## building this package locally
'python setup.py sdist'

## installing this package from Github
'pip install git+git@github.com:MahlatseMotsamai/git-demo-.git'

## updating this package from Github
'pip install --upgrade git+ git@github.com:MahlatseMotsamai/git-demo-.git'

python setup.py sdist
